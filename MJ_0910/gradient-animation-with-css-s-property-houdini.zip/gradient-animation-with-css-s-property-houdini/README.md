# Gradient Animation with CSS's @property (Houdini 🧙‍♂️)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/QWVoVrG](https://codepen.io/konstantindenerz/pen/QWVoVrG).

Demonstration of gradient animation with @property CSS feature.
Used in this tweet: https://twitter.com/kdenerz/status/1640661322915356674